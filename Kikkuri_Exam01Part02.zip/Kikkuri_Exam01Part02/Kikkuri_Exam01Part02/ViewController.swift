//
//  ViewController.swift
//  Kikkuri_Exam01Part02
//
//  Created by student on 2/23/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Authorlabel: UITextField!
    
    @IBOutlet weak var OutputLabel: UILabel!
    

    @IBOutlet weak var GenerateButton: UIButton!
    
    
    @IBOutlet weak var ResetButton: UIButton!
    
    var Quotes = [("Stephen King",
                 ["we write to taste life, in the moment and in retrospect",
                "Dreams are necessary to life","Life shrinks or expands"]),
    ("Paulo",
     ["tears are words that need to be written",
      "I'm not saying that love always takes you to heaven. Your life can become a nightmare",
      "And, when you want something, all the universe conspires in helping you to achieve it"]),
    ("charles", ["Always be poeit even in prose",
                "To survive, you must tell stories",
                "I write to discover what i know","honesty is best policy",
                "You can make anything by writing","Life quotes"]),
    ("Johannes Gutenberg", ["Start before you are ready",
                          "First draft is used just telling stories",
                          "keep going!!", "Donot break because its over","Everything is hard before it is easy","it hurt because it is matter"]),
    ("Jhon Irwing", ["Half my life is an act of revision",
                    "Start your day","life is beautiful","we rise by lifting others",
                    "Donot end your life with incompletion","Succes is not a destination"]),
    ("Stefen King", ["If you have no succes you will have critics"])]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        GenerateButton.isEnabled=false
        ResetButton.isEnabled=false
    
    }

    @IBAction func GenerateButton(_ sender: UIButton) {
        func safeGuard(){
            if Authorlabel.text==""{
                GenerateButton.isEnabled=false
                ResetButton.isEnabled=false
            }else{
                GenerateButton.isEnabled=true
                ResetButton.isEnabled=true
            }
        }
    }
    
    
    @IBAction func ResetButton(_ sender: UIButton) {
        ResetButton.isEnabled=true
        self.OutputLabel.text=""
    }
}

