//
//  ViewController.swift
//  Kolluri_SearchApp
//
//  Created by student on 2/28/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchButton: UIButton!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var showNextImagesBtn: UIButton!
    
    @IBOutlet weak var ShowPrevImagesBtn: UIButton!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var ResetButton: UIButton!
    
    var arr = [["Liberty","opera sydney","Paris","Pyramid","Tajmahal"],
        ["Book1","Book2","Book3","Book4","Book5"],
    ["chihuahua","Fluffy","german","GoldRetriever","Labrador"],
    ["backgroundimage","404"]]

    var places_array = ["places", "Liberty","opera sydney","Paris","Pyramid","Tajmahal"]
    
    var books_array = ["book","books","Book1","Book2","Book3","Book4","Book5","chetan bagat","comics","harry potter","frozen"]
    
    var dogs_array = ["dogs","Chihuahua","Fluffy","german","GoldRetriever","Labrador"]
    
    var variableOne = 0
    var pictureOne:Int!
    var pictureTwo:Int!
    var pictureThree:Int!
    var contentOne:Int!
    var contentTwo:Int!
    var contentThree:Int!
    var contentFour:Int!
    var contentFive:Int!
    var contentSix:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        ShowPrevImagesBtn.isHidden = true
        showNextImagesBtn.isHidden = true
        searchButton.isEnabled = false
        ResetButton.isHidden = true
        resultImage.image = UIImage(named: arr[3][0])
        topicInfoText.text = nil
    }
    
    @IBAction func searchTextField(_ sender: UITextField) {
        searchButton.isEnabled = true
        if(sender.text == ""){
            searchButton.isEnabled = false
            
        }
        else{
            ShowPrevImagesBtn.isEnabled = false
            showNextImagesBtn.isEnabled = false
            searchButton.isEnabled = true
            ResetButton.isHidden = false
    }
    }
    
    var places = [["Liberty","opera sydney","Paris","Pyramid","Tajmahal"],["The Statue of Liberty Enlightening the World was a gift of friendship from the people of France to the United States and is recognized as a universal symbol of freedom and democracy. The Statue of Liberty was dedicated on October 28, 1886. It was designated as a National Monument in 1924. Employees of the National Park Service have been caring for the colossal copper statue since 1933.","The Sydney Opera House is a multi-venue performing arts centre in Sydney. Located on the banks of Sydney Harbour, it is widely regarded as one of the world's most famous and distinctive buildings and a masterpiece of 20th century architecture. Designed by Danish architect Jørn Utzon, but completed by an Australian architectural team headed by Peter Hall.","The Eiffel Tower was built by Gustave Eiffel for the 1889 Exposition Universelle, which was to celebrate the 100th year anniversary of the French Revolution. Its construction in 2 years, 2 months and 5 days was a veritable technical and architectural achievement.","The Great Pyramid of Giza, also known as the Pyramid of Khufu, was built, according to most estimates, between about 2,550 to 2,490 B.C. The structure was truly colossal and remained the tallest human-built structure.","An immense mausoleum of white marble, built in Agra between 1631 and 1648 by order of the Mughal emperor Shah Jahan in memory of his favourite wife, the Taj Mahal is the jewel of Muslim art in India and one of the universally admired masterpieces of the world's heritage."]]
    
    var books = [["Book1","Book2","Book3","Book4","Book5"],["Half Girlfriend is an Indian English coming of age, young adult romance novel by Indian author Chetan Bhagat. The novel, set in rural Bihar, New Delhi, Patna, and New York, is the story of a Bihari boy in quest of winning over the girl he loves. Chetan Bhagat commented, Half-Girlfriend, to me, is a unique Indian phenomenon, where boys and girls are not clear about their relationship status with each other.", "The Harry Potter books make up the popular series written by J. K. Rowling. The series spans seven books. The books have been made into eight films by Warner Bros. The final book was split into two films. The books concern a wizard called Harry Potter and his journey through Hogwarts School of Witchcraft and Wizardry. The stories tell of him overcoming dangerous obstacles to defeat the Dark Wizard Lord Voldemort","Girls are forbidden to practice story magic. Only bad things happen when they do. Everyone knows this, but that doesnt stop twelve-year-old Kaya ADor from learning the basics from her older brother Hob. The trick is to sense a listener, one of the magical beings that inhabit the world, and tell it a story. If the listener is pleased and likes the story, they will allow the storyteller to work magic.","To distract Elsa from a gala being planned in her honor, Anna fills her schedule with fun bonding activities. But what starts as a distraction turns into an adventure when they find a secret door leading to passageways within the castle walls—and the door locks behind them, trapping them inside! Then, as they explore the narrow passages and sealed-off rooms, looking for an exit.","The comic book industry has been a part of our culture since the 1930s. While it has had its highs and lows, comic books are a vital part of our society, having become the pulse of pop culture that used to be seen as a childish thing for geeks and nerds.In a short span of 30 or so pages of collaborative work, writers and artists can band together to tell a story that not only reflects the current world around us."]]

    var dogs = [["Chihuahua","Fluffy","german","GoldRetriever","Labrador"],["Chihuahuas love nothing more than being with their people — even novice pet parents — and require a minimum of grooming and exercise. They make excellent apartment dogs who’ll get along with the whole family. Just make sure any children who approach know how to play gently with a small dog.","Naturally, fluffy dogs come with a lot of hair. And you might be wondering what that means when it comes to your carpets, furniture and clothes. But don’t worry; getting a fluffy dog doesn’t necessarily mean you’ll have to spend a ton of time vacuuming.","Generally considered dogkind's finest all-purpose worker, the German Shepherd Dog is a large, agile, muscular dog of noble character and high intelligence. Loyal, confident, courageous, and steady, the German Shepherd is truly a dog lover's delight. German Shepherd Dogs can stand as high as 26 inches at the shoulder and, when viewed in outline, presents a picture of smooth, graceful curves rather than angles.","The Golden Retriever is one of the most popular dog breeds in the United States. The breed’s friendly, tolerant attitude makes them great family pets, and their intelligence makes them highly capable working dogs.","The Labrador Retriever is America’s favorite dog, topping the most popular breeds list for a whopping 28 years in a row, and it’s easy to see why. These easygoing, affectionate, energetic dogs are family-friendly all-rounders, equally at home on the couch or in the field. Their name is misleading, though, as they don’t hail from Labrador but from Newfoundland, where they worked as duck retrievers and fisherman’s mates."]]

    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        pictureOne = 0
        pictureTwo = 0
        pictureThree = 0
        contentOne = 0
        contentTwo = 0
        contentThree = 0
        contentFour = 0
        contentFive = 0
        contentSix = 0
        ShowPrevImagesBtn.isHidden = false
        showNextImagesBtn.isHidden = false
        ShowPrevImagesBtn.isEnabled = false
        showNextImagesBtn.isEnabled = false
        ResetButton.isEnabled = true
        if(places_array.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            ShowPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: arr[0][pictureOne])
            //imageName.text = actor[0][contentOne]
            variableOne = 1
            topicInfoText.text = places[1][contentFour]
        }
        else if(books_array.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            ShowPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: arr[1][pictureTwo])
            //imageName.text = book[0][contentTwo]
            variableOne = 2
            topicInfoText.text = books[1][contentFive]
        }
        else if(dogs_array.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            ShowPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: arr[2][pictureThree])
            //imageName.text = book[0][contentThree]
            variableOne = 3
            topicInfoText.text = dogs[1][contentSix]
        }
        else{
            resultImage.image = UIImage(named: arr[3][1])
            topicInfoText.text = nil
            ShowPrevImagesBtn.isHidden = true
            showNextImagesBtn.isHidden = true
            ResetButton.isEnabled = true
        }
    }
    
    
    @IBAction func ShowPrevImageBtn(_ sender: UIButton) {
        if(variableOne == 1){
            pictureOne -= 1
            contentOne -= 1
            contentFour -= 1
            dataUpdate(imgNo: pictureOne)
        }
        if(variableOne == 2){
            pictureTwo -= 1
            contentTwo -= 1
            contentFive -= 1
            dataUpdate(imgNo: pictureTwo)
        }
        if(variableOne == 3){
            pictureThree -= 1
            contentThree -= 1
            contentSix -= 1
            dataUpdate(imgNo: pictureThree)
        }
    }
    
    
    @IBAction func showNextImageBtn(_ sender: UIButton) {
        if(variableOne == 1){
            pictureOne += 1
            contentOne += 1
            contentFour += 1
            dataUpdate(imgNo: pictureOne)
        }
        if(variableOne == 2){
            pictureTwo += 1
            contentTwo += 1
            contentFive += 1
            dataUpdate(imgNo: pictureTwo)
        }
        if(variableOne == 3){
            pictureThree += 1
            contentThree += 1
            contentSix += 1
            dataUpdate(imgNo: pictureThree)
        }

    }
    
    @IBAction func ResetButton(_ sender: UIButton) {
        ShowPrevImagesBtn.isHidden = true
        showNextImagesBtn.isHidden = true
        topicInfoText.text = nil
        ResetButton.isHidden = true
        searchTextField.text = ""
        resultImage.image = UIImage(named: arr[3][0])
        searchButton.isEnabled=false

    }
    
    func dataUpdate(imgNo: Int){
        if(variableOne == 1){
            if pictureOne == arr[0].count-1 {
                showNextImagesBtn.isEnabled = false
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[0][pictureOne])
                //imageName.text = actor[0][contentOne]
                topicInfoText.text = places[1][contentFour]
            }
            else if(pictureOne == 0){
                ShowPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[0][pictureOne])
                //imageName.text = actor[0][contentOne]
                topicInfoText.text = places[1][contentFour]
            }
            else{
                showNextImagesBtn.isEnabled = true
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[0][pictureOne])
                //imageName.text = actor[0][contentOne]
                topicInfoText.text = places[1][contentFour]
            }
        }
        if(variableOne == 2){
            if pictureTwo == arr[1].count-1 {
                showNextImagesBtn.isEnabled = false
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[1][pictureTwo])
                //imageName.text = book[0][contentTwo]
                topicInfoText.text = books[1][contentFive]
            }
            else if(pictureTwo == 0){
                ShowPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[1][pictureTwo])
                //imageName.text = book[0][contentTwo]
                topicInfoText.text = books[1][contentFive]
            }
            else{
                showNextImagesBtn.isEnabled = true
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[1][pictureTwo])
                //imageName.text = book[0][contentTwo]
                topicInfoText.text = books[1][contentFive]
            }
        }
        if(variableOne == 3){
            if pictureThree == arr[1].count-1 {
                showNextImagesBtn.isEnabled = false
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[2][pictureThree])
                //imageName.text = animal[0][contentThree]
                topicInfoText.text = dogs[1][contentSix]
            }
            else if(pictureThree == 0){
                ShowPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[2][pictureThree])
                //imageName.text = animal[0][contentThree]
                topicInfoText.text = dogs[1][contentSix]
            }
            else{
                showNextImagesBtn.isEnabled = true
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[2][pictureThree])
                //imageName.text = animal[0][contentThree]
                topicInfoText.text = dogs[1][contentSix]
            }
        }
    }
}
