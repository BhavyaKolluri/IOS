//
//  ViewController.swift
//  Kolluri_SearchApp
//
//  Created by student on 2/28/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchButton: UIButton!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var showNextImagesBtn: UIButton!
    
    @IBOutlet weak var ShowPrevImagesBtn: UIButton!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var ResetButton: UIButton!
    
    var arr = [["Book1","Book2","Book3","Book4","Book5"],
    ["Chihuahua","Fluffy","german","GoldRetriever","Labrador"],
    ["Liberty","opera sydney","Paris","Pyramid","Tajmahal"],
    ["bg","404"]]

    var books_array = ["book","books","Book1","Book2","Book3","Book4","Book5","chetan bagat","comics","harry potter","frozen"]
    
    var dogs_array = ["dogs","Chihuahua","Fluffy","german","GoldRetriever","Labrador"]
    
    var places_array = ["places", "Liberty","opera sydney","Paris","Pyramid","Tajmahal"]
    
    var topic = 0
    var imag1:Int!
    var imag2:Int!
    var imag3:Int!
    var name1:Int!
    var name2:Int!
    var name3:Int!
    var text1:Int!
    var text2:Int!
    var text3:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        ShowPrevImagesBtn.isHidden = true
        showNextImagesBtn.isHidden = true
        searchButton.isEnabled = false
        ResetButton.isHidden = true
        resultImage.image = UIImage(named: arr[3][0])
        topicInfoText.text = nil
    }
    
    @IBAction func searchTextField(_ sender: UITextField) {
        searchButton.isEnabled = true
        if(sender.text == ""){
            searchButton.isEnabled = false
            
        }
        else{
//            prevButton.isHidden = false
//            nextButton.isHidden = false
            ShowPrevImagesBtn.isEnabled = false
            showNextImagesBtn.isEnabled = false
            searchButton.isEnabled = true
            ResetButton.isHidden = false
    }
    }
    
    var places = [["Liberty","opera sydney","Paris","Pyramid","Tajmahal"],["The Statue of Liberty Enlightening the World was a gift of friendship from the people of France to the United States and is recognized as a universal symbol of freedom and democracy. The Statue of Liberty was dedicated on October 28, 1886. It was designated as a National Monument in 1924. Employees of the National Park Service have been caring for the colossal copper statue since 1933.","The Sydney Opera House is a multi-venue performing arts centre in Sydney. Located on the banks of Sydney Harbour, it is widely regarded as one of the world's most famous and distinctive buildings and a masterpiece of 20th century architecture. Designed by Danish architect Jørn Utzon, but completed by an Australian architectural team headed by Peter Hall, the building was formally opened on 20 October 1973[5] after a gestation beginning with Utzon's 1957 selection as winner of an international design competition. The Government of New South Wales, led by the premier, Joseph Cahill, authorised work to begin in 1958 with Utzon directing construction.","The Eiffel Tower was built by Gustave Eiffel for the 1889 Exposition Universelle, which was to celebrate the 100th year anniversary of the French Revolution. Its construction in 2 years, 2 months and 5 days was a veritable technical and architectural achievement. Utopia achieved, a symbol of technological prowess, at the end of the 19th Century it was a demonstration of French engineering, and a defining moment of the industrial era. As France’s symbol in the world, and the showcase of Paris, today it welcomes almost 7 million visitors a year, making it the most visited monument that you have to pay for in the world.","The Great Pyramid of Giza, also known as the Pyramid of Khufu, was built, according to most estimates, between about 2,550 to 2,490 B.C. The structure was truly colossal and remained the tallest human-built structure for many centuries until the construction of the Lincoln Cathedral (with its original spire) in 1311 AD. This is an incredible achievement, especially given the ancient Egyptian's relatively rudimentary knowledge of construction and engineering. Even today, building such a structure would be a massive engineering task.","An immense mausoleum of white marble, built in Agra between 1631 and 1648 by order of the Mughal emperor Shah Jahan in memory of his favourite wife, the Taj Mahal is the jewel of Muslim art in India and one of the universally admired masterpieces of the world's heritage. The Taj Mahal is located on the right bank of the Yamuna River in a vast Mughal garden that encompasses nearly 17 hectares, in the Agra District in Uttar Pradesh. It was built by Mughal Emperor Shah Jahan in memory of his wife Mumtaz Mahal with construction starting in 1632 AD and completed in 1648 AD, with the mosque, the guest house and the main gateway on the south, the outer courtyard and its cloisters were added subsequently and completed in 1653 AD. The existence of several historical and Quaranic inscriptions in Arabic script have facilitated setting the chronology of Taj Mahal."]]
    
    var books = [["Book1","Book2","Book3","Book4","Book5"],["Half Girlfriend is an Indian English coming of age, young adult romance novel by Indian author Chetan Bhagat. The novel, set in rural Bihar, New Delhi, Patna, and New York, is the story of a Bihari boy in quest of winning over the girl he loves. Chetan Bhagat commented, Half-Girlfriend, to me, is a unique Indian phenomenon, where boys and girls are not clear about their relationship status with each other. A boy may think he is more than friends with the girl, but the girl is still not his girlfriend. Hence, I thought we needed a term like 'Half girlfriend'. Because, in India, that is what most men get.", "The Harry Potter books make up the popular series written by J. K. Rowling. The series spans seven books. The books have been made into eight films by Warner Bros. The final book was split into two films. The books concern a wizard called Harry Potter and his journey through Hogwarts School of Witchcraft and Wizardry. The stories tell of him overcoming dangerous obstacles to defeat the Dark Wizard Lord Voldemort, who killed his parents when Harry was 15 months old. The first book, Harry Potter and the Philosopher's Stone, was published in 1997 by Bloomsbury in London. The final book, Harry Potter and the Deathly Hallows, sold more than 12 million copies in the U.S.",""]]

    var dogs = [["Chihuahua","Fluffy","german","GoldRetriever","Labrador"],["The African bush elephant (Loxodonta africana) is a very large herbivore with thick, almost hairless skin; a long, flexible, prehensile trunk; upper incisors forming long, curved, ivory tusks; and large, fan-shaped ears. Its closest living relative is the African forest elephant (Loxodonta cyclotis).","The black rhinoceros (Diceros bicornis) is a large herbivore with two upright horns on its nasal bridge. Its thick (1.5–5 cm), protective skin is formed from layers of collagen arranged in a lattice structure, and is very hard to puncture. Because it is now critically endangered, hunting is extremely limited.","The African buffalo (Syncerus caffer) is a large horned bovid. It is the only animal among the Big Five that is not on the “endangered” or “threatened” list.[11] The Cape buffalo (Syncerus caffer caffer) is considered by many to be the most dangerous to hunters of any of the Big Five.","The lion (Panthera leo) is a large, carnivorous feline found in Africa and northwest India. It has a short, tawny coat; a tufted tail; and, in the male, a heavy mane around the neck and shoulders. Lions are desirable to hunters because of the very real danger involved in hunting them.","The leopard (Panthera pardus) is a large, carnivorous feline. Its fur may be either black, or tawny with dark rosette-shaped markings. The leopard is considered the most difficult of the Big Five to hunt because of its nocturnal habits (it is most active between sunset and sunrise, although it may hunt during the day in some areas."]]

    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        imag1 = 0
        imag2 = 0
        imag3 = 0
        name1 = 0
        name2 = 0
        name3 = 0
        text1 = 0
        text2 = 0
        text3 = 0
        ShowPrevImagesBtn.isHidden = false
        showNextImagesBtn.isHidden = false
        ShowPrevImagesBtn.isEnabled = false
        showNextImagesBtn.isEnabled = false
        ResetButton.isEnabled = true
        if(places_array.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            ShowPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: arr[0][imag1])
            //imageName.text = actor[0][name1]
            topic = 1
            topicInfoText.text = places[1][text1]
        }
        else if(books_array.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            ShowPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: arr[1][imag2])
            //imageName.text = book[0][name2]
            topic = 2
            topicInfoText.text = books[1][text2]
        }
        else if(dogs_array.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            ShowPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: arr[2][imag3])
            //imageName.text = book[0][name3]
            topic = 3
            topicInfoText.text = dogs[1][text3]
        }
        else{
            resultImage.image = UIImage(named: arr[3][1])
//            resultImage.image = nil
            topicInfoText.text = nil
            //imageName.text = nil
            ShowPrevImagesBtn.isHidden = true
            showNextImagesBtn.isHidden = true
            ResetButton.isEnabled = true
        }
    }
    
    
    @IBAction func ShowPrevImageBtn(_ sender: UIButton) {
        if(topic == 1){
            imag1 -= 1
            name1 -= 1
            text1 -= 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 -= 1
            name2 -= 1
            text2 -= 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 -= 1
            name3 -= 1
            text3 -= 1
            dataUpdate(imgNo: imag3)
        }
    }
    
    
    @IBAction func showNextImageBtn(_ sender: UIButton) {
        if(topic == 1){
            imag1 += 1
            name1 += 1
            text1 += 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 += 1
            name2 += 1
            text2 += 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 += 1
            name3 += 1
            text3 += 1
            dataUpdate(imgNo: imag3)
        }

    }
    
    @IBAction func ResetButton(_ sender: UIButton) {
        ShowPrevImagesBtn.isHidden = true
        showNextImagesBtn.isHidden = true
        topicInfoText.text = nil
        ResetButton.isHidden = true
        searchTextField.text = ""
        resultImage.image = UIImage(named: arr[3][0])
        searchButton.isEnabled=false

    }
    
    func dataUpdate(imgNo: Int){
        if(topic == 1){
            if imag1 == arr[0].count-1 {
                showNextImagesBtn.isEnabled = false
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
                //imageName.text = actor[0][name1]
                topicInfoText.text = places[1][text1]
            }
            else if(imag1 == 0){
                ShowPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
                //imageName.text = actor[0][name1]
                topicInfoText.text = places[1][text1]
            }
            else{
                showNextImagesBtn.isEnabled = true
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
                //imageName.text = actor[0][name1]
                topicInfoText.text = places[1][text1]
            }
        }
        if(topic == 2){
            if imag2 == arr[1].count-1 {
                showNextImagesBtn.isEnabled = false
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
                //imageName.text = book[0][name2]
                topicInfoText.text = books[1][text2]
            }
            else if(imag2 == 0){
                ShowPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
                //imageName.text = book[0][name2]
                topicInfoText.text = books[1][text2]
            }
            else{
                showNextImagesBtn.isEnabled = true
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
                //imageName.text = book[0][name2]
                topicInfoText.text = books[1][text2]
            }
        }
        if(topic == 3){
            if imag3 == arr[1].count-1 {
                showNextImagesBtn.isEnabled = false
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
                //imageName.text = animal[0][name3]
                topicInfoText.text = dogs[1][text3]
            }
            else if(imag3 == 0){
                ShowPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
                //imageName.text = animal[0][name3]
                topicInfoText.text = dogs[1][text3]
            }
            else{
                showNextImagesBtn.isEnabled = true
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
                //imageName.text = animal[0][name3]
                topicInfoText.text = dogs[1][text3]
            }
        }
    }
}
