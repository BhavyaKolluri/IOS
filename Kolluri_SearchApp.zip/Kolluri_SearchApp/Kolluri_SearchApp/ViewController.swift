//
//  ViewController.swift
//  Kolluri_SearchApp
//
//  Created by student on 2/28/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchButtonAction: UIButton!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var showNextImagesBtn: UIButton!
    
    @IBOutlet weak var ShowPrevImagesBtn: UIButton!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    var array1 = [["Book1","Book2","Book3","Book4","Book5"],
    ["Chihuahua","Fluffy","german","GoldRetriever","Labrador"],
    ["Liberty","opera sydney","Paris","Pyramid","Tajmahal"]]

    var books_array = ["book","books","Book1","Book2","Book3","Book4","Book5","chetan bagat","comics","harry potter","frozen"]
    
    var dogs_array = ["dogs","Chihuahua","Fluffy","german","GoldRetriever","Labrador"]
    
    var places_array = ["places", "Liberty","opera sydney","Paris","Pyramid","Tajmahal"]
    
    override func viewDidLoad() {
 
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}

