//
//  CountViewController.swift
//  G10Milestone3
//
//  Created by student on 5/5/22.
//

import UIKit

class CountViewController: UIViewController {
    
    var age : String?
    var weight : String?
    var gender : String?
    var exercise : String?

    @IBOutlet weak var ageOutlet: UILabel!
    
    @IBOutlet weak var weightOutlet: UILabel!
    
    @IBOutlet weak var genderOutlet: UILabel!
    
    @IBOutlet weak var exerciseOutlet: UILabel!
    
    @IBOutlet weak var calorieOutlet: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        ageOutlet.text = age
        weightOutlet.text = weight
        genderOutlet.text = gender
        exerciseOutlet.text = exercise
    
        if(gender == "Male" || gender == "male" ){
            if(Int(age!)! >= 0  &&  Int(age!)! <= 50){
                if(Int(weight!)! > 0 && Int(weight!)! <= 50){
                    if(exercise == "low"){
                        calorieOutlet.text = "1273 Calories"
                    }
                    else if(exercise == "medium"){
                        calorieOutlet.text = "1379 Calories"
                    }
                    else if(exercise == "high"){
                        calorieOutlet.text = "1486 Calories"
                    }
                }
                else if(Int(weight!)! > 50 && Int(weight!)! <= 150){
                    if(exercise == "low"){
                        calorieOutlet.text = "973 Calories"
                    }
                    else if(exercise == "medium"){
                        calorieOutlet.text = "1179 Calories"
                    }
                    else if(exercise == "high"){
                        calorieOutlet.text = "1186 Calories"
                    }
                }
            }
            else if(Int(age!)! > 50  &&  Int(age!)! <= 100){
                if(Int(weight!)! > 0 && Int(weight!)! <= 50){
                    if(exercise == "low"){
                        calorieOutlet.text = "1200 Calories"
                    }
                    else if(exercise == "medium"){
                        calorieOutlet.text = "1250 Calories"
                    }
                    else if(exercise == "high"){
                        calorieOutlet.text = "1300 Calories"
                    }
                }
                else if(Int(weight!)! > 50 && Int(weight!)! <= 150){
                    if(exercise == "low"){
                        calorieOutlet.text = "950 Calories"
                    }
                    else if(exercise == "medium"){
                        calorieOutlet.text = "1050 Calories"
                    }
                    else if(exercise == "high"){
                        calorieOutlet.text = "1150 Calories"
                    }
                }
            }
        }
        else if(gender == "FeMale" || gender == "female" ){
            if(Int(age!)! >= 0  &&  Int(age!)! <= 50){
                if(Int(weight!)! > 0 && Int(weight!)! <= 50){
                    if(exercise == "low"){
                        calorieOutlet.text = "1000 Calories"
                    }
                    else if(exercise == "medium"){
                        calorieOutlet.text = "1100 Calories"
                    }
                    else if(exercise == "high"){
                        calorieOutlet.text = "1200 Calories"
                    }
                }
                else if(Int(weight!)! > 50 && Int(weight!)! <= 150){
                    if(exercise == "low"){
                        calorieOutlet.text = "953 Calories"
                    }
                    else if(exercise == "medium"){
                        calorieOutlet.text = "1187 Calories"
                    }
                    else if(exercise == "high"){
                        calorieOutlet.text = "1286 Calories"
                    }
                }
            }
            else if(Int(age!)! > 50  &&  Int(age!)! <= 100){
                if(Int(weight!)! > 0 && Int(weight!)! <= 50){
                    if(exercise == "low"){
                        calorieOutlet.text = "1100 Calories"
                    }
                    else if(exercise == "medium"){
                        calorieOutlet.text = "1200 Calories"
                    }
                    else if(exercise == "high"){
                        calorieOutlet.text = "1275 Calories"
                    }
                }
                else if(Int(weight!)! > 50 && Int(weight!)! <= 150){
                    if(exercise == "low"){
                        calorieOutlet.text = "940 Calories"
                    }
                    else if(exercise == "medium"){
                        calorieOutlet.text = "1040 Calories"
                    }
                    else if(exercise == "high"){
                        calorieOutlet.text = "1050 Calories"
                    }
                }
            }
        }
        else{
            print("Please enter valid input!!!")
        }
    }
    
    
    @IBAction func nextButton(_ sender: UIButton) {
    }
}
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
