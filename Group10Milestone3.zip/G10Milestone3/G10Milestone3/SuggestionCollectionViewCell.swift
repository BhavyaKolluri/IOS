//
//  SuggestionCollectionViewCell.swift
//  G10Milestone3
//
//  Created by student on 5/5/22.
//

import UIKit

class SuggestionCollectionViewCell: UICollectionViewCell {
    
}

import UIKit

class MealViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Food_array.count

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = mealTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
                cell.textLabel?.text = Food_array[indexPath.row].category
                return cell
    }
    
    @IBOutlet weak var mealTableView: UITableView!
    var Food_array = food_stack

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
               self.title = "Diet App"
                mealTableView.delegate = self
                mealTableView.dataSource = self
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
                if transition == "foodSegue"{
                    let destination = segue.destination as! FoodViewController
                    
                    destination.array_foodSecond = Food_array[(mealTableView.indexPathForSelectedRow!.row)].foods
                    
                    destination.title1 = Food_array[(mealTableView.indexPathForSelectedRow!.row)].category
                }
    }


}

