//
//  FoodData.swift
//  G10Milestone3
//
//  Created by student on 5/5/22.
//

import Foundation
import UIKit

struct Foods {
    var title:String
    var image:UIImage
    var calorie:String
    
}

struct MealType{
    var category:String
    var foods:[Foods] = []
}

let foodmeal1 = MealType(category: "Breakfast",
                            foods: [
                    Foods(title: "Egg white and black pepper omelette", image: UIImage(named: "egg")!, calorie: "91"),
                    Foods(title: "Cinnamon toast", image: UIImage(named: "cinnamon")!, calorie: "92"),
                    Foods(title: "Grapefruit, satsuma and pomegranate ", image: UIImage(named: "grapefruit")!, calorie: "75"),
                    Foods(title: "Watermelon ", image: UIImage(named: "watermelon")!, calorie: "65"),
                    Foods(title: "Banana and honey ", image: UIImage(named: "banana")!, calorie: "99"),
                    Foods(title: "Beans on toast", image: UIImage(named: "beans")!, calorie: "97")
                   ])

let foodmeal2 = MealType(category: "Lunch",
                            foods: [
                    Foods(title: "Steak, chicory and orange salad", image: UIImage(named: "Steak,chicoryandorangesalad")!, calorie: "180"),
                    Foods(title: "Spring vegetable soup", image: UIImage(named: "Springvegetablesoup")!, calorie: "130"),
                    Foods(title: "Bean and pepper salad", image: UIImage(named: "Beanandpepper salad")!, calorie: "137"),
                    Foods(title: "spinach tortilla ", image: UIImage(named: "spinachtortilla")!, calorie: "196"),
                    Foods(title: "Spanish tortilla with artichokes", image: UIImage(named: "Spanishtortilla")!, calorie: "127"),
                    
                   ])

let foodmeal3  = MealType(category: "Dinner",
                            foods: [
                    Foods(title: "Grilled Lime Chicken", image: UIImage(named: "GrilledLimeChicken")!, calorie: "78"),
                    Foods(title: "Kimchi Cauliflower Fried Rice", image: UIImage(named: "KimchiCauliflowerFriedRice")!, calorie: "76"),
                    Foods(title: "Ravioli with Snap Peas & Mushrooms", image: UIImage(named: "PeasMushrooms")!, calorie: "75"),
                    Foods(title: "Chicken Rice Bowl", image: UIImage(named: "ChickenRiceBowl")!, calorie: "79"),
                    Foods(title: "Caribbean Shrimp Bowl", image: UIImage(named: "CaribbeanShrimpBowl")!, calorie: "74"),
                    Foods(title: "Salmon with Spinach & White Beans", image: UIImage(named: "salmon")!, calorie: "72")
                   ])



let food_stack = [foodmeal1 ,foodmeal2 ,foodmeal3 ]

