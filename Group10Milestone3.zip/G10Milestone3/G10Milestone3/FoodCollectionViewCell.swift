//
//  FoodCollectionViewCell.swift
//  G10Milestone3
//
//  Created by student on 5/5/22.
//

import UIKit

class FoodCollectionViewCell: UICollectionViewCell {
    


    @IBOutlet weak var foodCollectionView: UIImageView!
    func assignFood(with food:Foods){
               foodCollectionView.image = food.image
           }
}
