//
//  CalorieViewController.swift
//  Group10Milestone2
//
//  Created by student on 5/4/22.
//

import UIKit

class CalorieViewController: UIViewController {

    @IBOutlet weak var ageOutlet: UITextField!
    
    @IBOutlet weak var weightOutlet: UITextField!
    
    @IBOutlet weak var genderOutlet: UITextField!
    
    @IBOutlet weak var exerciseOutlet: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ageOutlet.isEnabled = true
        weightOutlet.isEnabled = true
        genderOutlet.isEnabled = true

        // Do any additional setup after loading the view.
    }
    
    @IBAction func ageAction(_ sender: Any) {
        ageOutlet.isEnabled = true
    }
    
    @IBAction func weightAction(_ sender: UITextField) {
        weightOutlet.isEnabled = true
    }
    
    @IBAction func genderAction(_ sender: UITextField) {
        genderOutlet.isEnabled = true
    }
    
    @IBAction func exerciseAction(_ sender: UITextField) {
    }
    
    @IBAction func submit(_ sender: UIButton) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "countSegue"{
            let destination = segue.destination as! CountViewController
            destination.age=ageOutlet.text!
            destination.weight=weightOutlet.text!
            destination.gender=genderOutlet.text!
            destination.exercise=exerciseOutlet.text!
            
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


}
