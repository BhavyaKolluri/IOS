//
//  ViewController.swift
//  Group10Milestone2
//
//  Created by student on 4/7/22.
//

import UIKit

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

