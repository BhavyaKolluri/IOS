//
//  ViewController.swift
//  Kolluri_Calculator
//
//  Created by Kolluri,Bhavya on 2/16/22.
//

import UIKit

class ViewController: UIViewController {
    

    @IBOutlet weak var displayLabel: UILabel!
    
    var inputValueOne = ""
    var inputValueTwo = ""
    var operation = ""
    var operationValueChanged = false
    var calculatedValue = ""
    var differentOperators = false
    var result = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        displayLabel.text = "0"
    }
    
    @IBAction func buttonAC(_ sender: UIButton) {
        inputValueTwo = ""
        inputValueOne = ""
        operationValueChanged = false
        operation = ""
        calculatedValue = ""
        displayLabel.text = "0"
        differentOperators=false
    }
    
    @IBAction func buttonC(_ sender: UIButton) {
        inputValueTwo = ""
    }
    @IBAction func buttonChangeSign(_ sender: UIButton) {
        if inputValueOne != "" {
            displayLabel.text = "-" + String(displayLabel.text!)
            inputValueOne = "\(displayLabel.text!)"
        }
        else{
            displayLabel.text = "-" + String(displayLabel.text!)
            inputValueTwo = "\(displayLabel.text!)"
        }
    }
    @IBAction func buttonDivideSign(_ sender: UIButton) {
    }
    @IBAction func button7(_ sender: UIButton) {
        let number = "7"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }
    }
    @IBAction func button8(_ sender: UIButton) {
        let number = "8"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }
    }
    @IBAction func button9(_ sender: UIButton) {
        let number = "9"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }
    }
    @IBAction func buttonMulitply(_ sender: UIButton) {
        let temp = calTemp(operation)
        operation = "*"
        calculatedValue=""
        displayLabel.text = (temp != "") ? resultFormatter(temp) : ""
        operationValueChanged=true
    }
    
    @IBAction func button4(_ sender: UIButton) {
        let number = "4"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }
    }
    @IBAction func button5(_ sender: UIButton) {
        let number = "5"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }
    }
    @IBAction func button6(_ sender: UIButton) {
        let number = "6"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }
    }
    @IBAction func buttonSubstract(_ sender: UIButton) {
        let temp = calTemp(operation)
        operation = "-"
        displayLabel.text = (temp != "") ? resultFormatter(temp) : ""
        if temp != "" {
                    if inputValueTwo != ""{
                differentOperators = true
                calculatedValue = inputValueTwo;
                if operationValueChanged {
                    result = String(Double(temp)! - Double(inputValueTwo)!)
                    displayLabel.text! = resultFormatter(result)
                }
            }
        }
        operationValueChanged = true
    }
    
    @IBAction func button1(_ sender: UIButton) {
        let number = "1"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }
    }
    @IBAction func button2(_ sender: UIButton) {
        let number = "2"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }
    }
    @IBAction func button3(_ sender: UIButton) {
        let number = "3"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }
    }
    @IBAction func buttonPlus(_ sender: UIButton) {
        let temp = calTemp(operation)
        operation = "+"
        calculatedValue=""
        displayLabel.text = (temp != "") ? resultFormatter(temp) : ""
        operationValueChanged=true
    }
    
    @IBAction func button0(_ sender: UIButton) {
        let number = "0"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }
    }
    @IBAction func buttonDot(_ sender: UIButton) {
        let number = "."
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }
    }
    @IBAction func buttonMod(_ sender: UIButton) {
        let value = calTemp(operation)
        operation = "/"
        displayLabel.text = (value != "") ? resultFormatter(value) : ""
        if value != "" {
            if inputValueTwo != ""{
                differentOperators = true
                if operationValueChanged {
                    result = String(Double(value)! / Double(inputValueTwo)!)
                    if result == "inf"{
                        displayLabel.text! = "Error"
                    }else{
                        displayLabel.text! = resultFormatter(result)
                    }
                }
            }
        }
        operationValueChanged = true
    }
    @IBAction func buttonEquals(_ sender: UIButton) {
        var res = ""
        switch operation {
        case "+":

            if calculatedValue != "" {
                res = String(Double(inputValueOne)! + Double(calculatedValue)!)
                displayLabel.text = resultFormatter(res)
                 inputValueTwo = calculatedValue
            }else{

                res = String(Double(inputValueOne)! + Double(inputValueTwo)!)
                displayLabel.text = resultFormatter(res)
            }
            inputValueOne = res

            break
        case "*":
            if calculatedValue != "" {
                res = String(Double(inputValueOne)! * Double(calculatedValue)!)
                displayLabel.text = resultFormatter(res)
            }else{
                res = String(Double(inputValueOne)! * Double(inputValueTwo)!)
                displayLabel.text = resultFormatter(res)
            }
            inputValueOne = res

            break
        case "-":
            if calculatedValue != "" {
                res = String(Double(inputValueOne)! - Double(calculatedValue)!)
                displayLabel.text = resultFormatter(res)
                //                number2 = ""
            }else{
                res = String(Double(inputValueOne)! - Double(inputValueTwo)!)
                displayLabel.text = resultFormatter(res)
            }
            inputValueOne = res
            break
        case "/":
            if displayLabel.text == "Error"{
                inputValueTwo = ""
                inputValueOne = ""
                operationValueChanged = false
                operation = ""
                calculatedValue = ""
                displayLabel.text = "0"
                differentOperators=false
            }else{
                if calculatedValue != "" {
                    res = String(Double(inputValueOne)! / Double(calculatedValue)!)
                    if res == "inf"{
                        displayLabel.text! = "Error"
                        return
                    }else{
                        displayLabel.text = resultFormatter(res)
                    }
                }else{
                    res = String(Double(inputValueOne)! / Double(inputValueTwo)!)
                    if res == "inf"{
                        displayLabel.text! = "Error"
                        return
                    }else{
                        displayLabel.text = resultFormatter(res)
                    }
                }
                inputValueOne = res
            }
            break
        default:
            print("Nothing")
        }
    }
    
    func setData(_ number: String){
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }
    }
    
    func calTemp(_ operation:String)->String {
        if inputValueOne != "" && inputValueTwo != ""{
            if operation == "+"{
                inputValueOne = String(Double(inputValueOne)! + Double(inputValueTwo)!)
                calculatedValue = inputValueTwo
                inputValueTwo = ""
                return String(inputValueOne)
                //                return String(Double(number1)! + Double(number2)!)
            }
            if operation == "-"{
                inputValueOne = String(Double(inputValueOne)! - Double(inputValueTwo)!)
                calculatedValue = inputValueTwo
                inputValueTwo = ""
                return String(inputValueOne)
            }
            if operation == "*"{
                inputValueOne = String(Double(inputValueOne)! * Double(inputValueTwo)!)
                calculatedValue = inputValueTwo
                inputValueTwo = ""
                return String(inputValueOne)
            }
            if operation == "/"{
                inputValueOne = String(Double(inputValueOne)! / Double(inputValueTwo)!)
                calculatedValue = inputValueTwo
                inputValueTwo = ""
                return String(inputValueOne)
            }
        }
        return ""
    }

    func resultFormatter(_ result:String)->String {
        let value = Double(result)!
        var resultStr = String(round(value * 100000) / 100000.0)

        if resultStr.contains(".0"){
            resultStr.removeSubrange(resultStr.index(resultStr.endIndex, offsetBy: -2)..<resultStr.endIndex)
        }

        return resultStr
    }
}

