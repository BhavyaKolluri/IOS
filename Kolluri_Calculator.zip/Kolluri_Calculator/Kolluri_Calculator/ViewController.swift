//
//  ViewController.swift
//  Kolluri_Calculator
//
//  Created by Kolluri,Bhavya on 2/16/22.
//

import UIKit

class ViewController: UIViewController {
    

    @IBOutlet weak var displayLabel: UILabel!
    
    var input1 = ""
    var input2 = ""
    var finalResult = ""
    var calculation = ""
    var number = ""
    var finalResult2 = false
    var mode = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func buttonAC(_ sender: UIButton) {
        clearAll()
    }
    
    @IBAction func buttonC(_ sender: UIButton) {
        input2 = ""
        displayLabel.text = ""
    }
    @IBAction func buttonChangeSign(_ sender: UIButton) {
        if input1 == ""{
            displayLabel.text = "-" + displayLabel.text!
            input1 = "\(displayLabel.text!)"
        }
        else{
            displayLabel.text = "-" + displayLabel.text!
            input2 = "\(displayLabel.text!)"
        }
    }
    
    @IBAction func buttonDivideSign(_ sender: UIButton) {
        let temp = calTemp( calculation)
         calculation = "/"
        displayLabel.text = (temp != "") ?  finalResultFormatter(temp) : ""
        if temp != "" {
            // mode = true
            if input2 != ""{
                mode = true
                if   finalResult2 {
                     finalResult = String(Double(temp)! / Double(input2)!)
                    print( finalResult)
                    if  finalResult == "inf"{
                        displayLabel.text! = "Error"
                    }
                    else{
                        displayLabel.text! =  finalResultFormatter( finalResult)
                    }
                }
            }
        }
          finalResult2 = true

    }
    
    @IBAction func button7(_ sender: UIButton) {
        setData("7")
    }
    
    @IBAction func button8(_ sender: UIButton) {
        setData("8")
    }
    
    @IBAction func button9(_ sender: UIButton) {
        setData("9")
    }
    
    @IBAction func buttonMulitply(_ sender: UIButton) {
        let temp = calTemp( calculation)
        print("temp is \(temp)")
         calculation = "*"
         number=""
        displayLabel.text = (temp != "") ?  finalResultFormatter(temp) : ""
          finalResult2 = true
    }
    
    @IBAction func button4(_ sender: UIButton) {
        setData("4")
    }
    
    @IBAction func button5(_ sender: UIButton) {
        setData("5")
    }
    
    @IBAction func button6(_ sender: UIButton) {
        setData("6")
    }
    
    @IBAction func buttonSubstract(_ sender: UIButton) {
        if(input1 == ""){
           input1 = "0"
        }
        let temp = calTemp( calculation)
        print("temp is \(temp)")
         calculation = "-"
         number=""
        displayLabel.text = (temp != "") ?  finalResultFormatter(temp) : ""
          finalResult2 = true
    }
    
    @IBAction func button1(_ sender: UIButton) {
        setData("1")
    }
    
    @IBAction func button2(_ sender: UIButton) {
        setData("2")
    }
    
    @IBAction func button3(_ sender: UIButton) {
        setData("3")
    }
    
    @IBAction func buttonPlus(_ sender: UIButton) {
        let temp = calTemp( calculation)
        print("temp is \(temp)")
         calculation = "+"
         number=""
        displayLabel.text = (temp != "") ?  finalResultFormatter(temp) : ""
          finalResult2 = true
    }
    
    @IBAction func button0(_ sender: UIButton) {
        setData("0")
    }
    
    @IBAction func buttonDot(_ sender: UIButton) {
        setData(".")
    }
    
    @IBAction func buttonMod(_ sender: UIButton) {
        let temp = calTemp( calculation)
        print("temp is \(temp)")
         calculation = "%"
         number=""
        displayLabel.text = (temp != "") ?  finalResultFormatter(temp) : ""
          finalResult2 = true
    }
    
    @IBAction func buttonEquals(_ sender: UIButton) {
        var res = ""
        switch  calculation {
            case "+":
            if  number != "" {
                res = String(Double(input1)! + Double( number)!)
                displayLabel.text =  finalResultFormatter(res)
                input2 =  number
            }
            else{
                res = String(Double(input1)! + Double(input2)!)
                displayLabel.text =  finalResultFormatter(res)
            }
            input1 = res
            break
            case "*":
            if  number != "" {
                res = String(Double(input1)! * Double( number)!)
                displayLabel.text =  finalResultFormatter(res)
            }
            else{
                res = String(Double(input1)! * Double(input2)!)
                displayLabel.text =  finalResultFormatter(res)
            }
            input1 = res
            break
            case "-":
            if  number != "" {
                res = String(Double(input1)! - Double( number)!)
                displayLabel.text =  finalResultFormatter(res)
            }
            else {
                res = String(Double(input1)! - Double(input2)!)
                displayLabel.text =  finalResultFormatter(res)
            }
            input1 = res
            break
            case "/":
            if displayLabel.text == "Error"{
                clearAll()
            }
            else {
                if  number != "" {
                    res = String(Double(input1)! / Double( number)!)
                    if res == "inf"{
                        displayLabel.text! = "Error"
                        return
                    }
                    else {
                        displayLabel.text =  finalResultFormatter(res)
                    }
                }
                else {
                    res = String(Double(input1)! / Double(input2)!)
                    if res == "inf"{
                        displayLabel.text! = "Error"
                        return
                    }
                    else {
                        displayLabel.text =  finalResultFormatter(res)
                    }
                }
                input1 = res
            }
            break
            case "%":
            if  number != "" {
                displayLabel.text =  finalResultFormatter(res)
                let s1 = Double(input1)!
                let s2 = Double( number)!
                var r = s1.remainder(dividingBy: s2)
                res = String(r)
                input2 =  number
            }
            else {
                let s1 = Double(input1)!
                let s2 = Double(input2)!
                var r = s1.remainder(dividingBy: s2)
                res = String(r)
                displayLabel.text =  finalResultFormatter(res)
            }
            input1 = res
            break
        default:
            print("IOS")
        }
    }
    
    func clearAll(){
        input1 = ""
        input2 = ""
          finalResult2 = false
         calculation = ""
         number = ""
        displayLabel.text = ""
        mode = false
    }
    
    func setData(_ number: String){
        if displayLabel.text == "0"{
            displayLabel.text = ""
        }
        else{
            if !finalResult2{
                displayLabel.text! += number
                input1 += number
            }
            else{
                if !mode{
                    displayLabel.text! += number
                    input2 += number
                }
                else{
                    displayLabel.text = ""
                    displayLabel.text! += number
                    input2 += number
                }
            }
        }
    }
    
        func calTemp(_  calculation:String)->String {
            if input1 != "" && input2 != ""{
                if  calculation == "+"{
                    input1 = String(Double(input1)! + Double(input2)!)
                     number = input2
                    input2 = ""
                    return String(input1)
                }
                if  calculation == "-"{
                    input1 = String(Double(input1)! - Double(input2)!)
                     number = input2
                    input2 = ""
                    return String(input1)
                }
                if  calculation == "*"{
                    input1 = String(Double(input1)! * Double(input2)!)
                     number = input2
                    input2 = ""
                    return String(input1)
                }
                if  calculation == "/"{
                    input1 = String(Double(input1)! / Double(input2)!)
                     number = input2
                    input2 = ""
                    return String(input1)
                }
                if  calculation == "%" {
                    let s1 = Double(input1)!
                    let s2 = Double(input2)!
                    var r = s1.remainder(dividingBy: s2)
                    input1 = String(r)
                     number = input2
                    input2 = ""
                    return String(input1)
                }
            }
            return ""
        }
        
        func  finalResultFormatter(_  finalResult:String)->String {
            let value = Double( finalResult)!
            var finalResultStr = String(round(value * 100000) / 100000.0)
            if  finalResultStr.contains(".0"){
                 finalResultStr.removeSubrange(finalResultStr.index(finalResultStr.endIndex, offsetBy: -2)..<finalResultStr.endIndex)
            }
            return  finalResultStr
        }
}

