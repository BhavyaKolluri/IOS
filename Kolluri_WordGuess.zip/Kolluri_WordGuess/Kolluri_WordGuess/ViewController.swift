//
//  ViewController.swift
//  Kolluri_WordGuess
//
//  Created by student on 3/31/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsMissedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var guessALetterButton: UIButton!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var playAgainButton: UIButton!
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    var words = [["CRICKET", "game"],
                 ["JUPITER", "planet"],
                 ["CAT", "animal"],
                 ["MACBOOK", "apple device"],
                 ["MANGO", "fruit"]]
    var images = ["cricket","Jupiter","cat","macbook","mango","tryagain"]
    
    var maxNumOfWrongGuesses = 11
    var count = 0
    var NumberOfCharacters = ""
    var wordGuessed = ""
    var value = 0
    var wordOne = ""
    var wordTwo = ""
    var wordThree = ""
    var characterOne = 0
    var characterTwo = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        guessALetterButton.isEnabled = false
        wordGuessed = words[count][0]
        userGuessLabel.text = ""
        wordOne = wordsGuessedLabel.text!
        wordTwo = wordsMissedLabel.text!
        wordThree = wordsRemainingLabel.text!
        totalWordsLabel.text = totalWordsLabel.text!+String(words.count)
        wordsGuessedLabel.text = wordOne+String(count)
        wordsRemainingLabel.text = wordThree+String(words.count)
        wordsMissedLabel.text = wordTwo+String(count)
        updateUnderscores();
        hintLabel.text = "Hint: "+words[count][1]
    }
    
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        let letter = guessLetterField.text!
        guessLetterField.resignFirstResponder()
        NumberOfCharacters = NumberOfCharacters + letter
        var openWord = ""
        for l in wordGuessed{
            if NumberOfCharacters.contains(l){
                openWord += "\(l)"
            }
            else{
                openWord += "_ "
            }
        }
        value = value + 1
        guessCountLabel.text = "You have made \(value)  Guesses";
        maxNumOfWrongGuesses = maxNumOfWrongGuesses - 1
        userGuessLabel.text = openWord
        guessLetterField.text = ""
        if (userGuessLabel.text!.contains("_") == false){
            count += 1
            guessCountLabel.text = "You won! it took you \(value) attemps to guess the word!";
            guessLetterField.isEnabled = false
            characterOne = characterOne + 1
            wordsGuessedLabel.text = wordOne+String(characterOne)
            wordsMissedLabel.text = wordTwo+String(characterTwo)
            wordsRemainingLabel.text = wordThree+String((words.count) - count)
            maxNumOfWrongGuesses = 10
            value = 0
            playAgainButton.isHidden = false;
            guessALetterButton.isEnabled = false;
            imageViewOutlet.image = UIImage(named: images[count-1])
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 0, animations: {
                self.imageViewOutlet.frame.origin.x = -100
                self.imageViewOutlet.frame.origin.y = -100
                self.imageViewOutlet.image = UIImage(named: self.images[self.count-1])
            },completion: {_ in
                self.imageViewOutlet.frame.origin.x = 100
                self.imageViewOutlet.frame.origin.y = 650
            })
            if (count == words.count){
                guessCountLabel.text = "You have tried all the words! Restart from the beginnning?"
                characterOne = 0
                characterTwo = 0
                count = 0
            }
        }
        if(maxNumOfWrongGuesses == 0 && userGuessLabel.text!.contains("_") == true){
            count += 1
            value = 0
            characterTwo = characterTwo + 1
            guessCountLabel.text = "You are out of all guesses. Try again?";
            guessLetterField.isEnabled = false
            wordsGuessedLabel.text = wordOne+String(characterOne)
            wordsMissedLabel.text = wordTwo+String(characterTwo)
            wordsRemainingLabel.text = wordThree+String((words.count) - count)
            maxNumOfWrongGuesses = 10
            playAgainButton.isHidden = false;
            guessALetterButton.isEnabled = false;
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 0, animations: {
                self.imageViewOutlet.frame.origin.x = -100
                self.imageViewOutlet.frame.origin.y = -100
                self.imageViewOutlet.image = UIImage(named: self.images[5])
            },completion: {_ in
                self.imageViewOutlet.frame.origin.x = 100
                self.imageViewOutlet.frame.origin.y = 650
            })
            if (count == words.count){
                guessCountLabel.text = "You have tried all the words! Restart from the beginnning?"
                characterOne = 0
                characterTwo = 0
                count = 0
            }
        }
        guessALetterButton.isEnabled = false
    }
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
        playAgainButton.isHidden = true
        imageViewOutlet.image = UIImage(named: "")
        NumberOfCharacters = ""
        wordsRemainingLabel.text = wordThree+String((words.count) - count)
        if(count == 0){
            wordGuessed = words[count][0]
            userGuessLabel.text = ""
            updateUnderscores()
            guessLetterField.isEnabled = true
            hintLabel.text = "Hint: "
            hintLabel.text! += words[count][1]
            wordsGuessedLabel.text = wordOne+String(characterOne)
            wordsMissedLabel.text = wordTwo+String(characterTwo)
            wordsRemainingLabel.text = wordThree+String((words.count) - count)
            guessCountLabel.text = "You have made \(value)  Guesses";
        }
        else{
            wordGuessed = words[count][0]
            guessCountLabel.text = "You have made \(value)  Guesses";
            guessLetterField.isEnabled = true
            //fetch the hint related to the word
            hintLabel.text = "Hint: "
            hintLabel.text! += words[count][1]
            //Enabling the check button.
            guessALetterButton.isEnabled = false
            userGuessLabel.text = ""
            updateUnderscores()
        }
    }
    
    @IBAction func guessLFAction(_ sender: UITextField) {
        var guessText = guessLetterField.text!;
        guessText = String(guessText.last ?? " ").trimmingCharacters(in: .whitespaces)
        guessLetterField.text = guessText
        if guessText.isEmpty{
            guessALetterButton.isEnabled = false
        }
        else{
            guessALetterButton.isEnabled = true
        }
    }
    
    func updateUnderscores(){
        for _ in wordGuessed{
            userGuessLabel.text! += "_ "
        }
    }
}
