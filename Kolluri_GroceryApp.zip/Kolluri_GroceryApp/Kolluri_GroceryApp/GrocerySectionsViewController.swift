//
//  ViewController.swift
//  Kolluri_GroceryApp
//
//  Created by student on 4/12/22.
//

import UIKit

class GrocerySectionsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var assign6Grocery = Grocery()
    @IBOutlet weak var grocerySectionsTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Grocery Sections"
        // Do any additional setup after loading the view.
        grocerySectionsTableView.delegate = self
        grocerySectionsTableView.dataSource = self
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return grocerys.count;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let assign6Cell = grocerySectionsTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        assign6Cell.textLabel?.text = grocerys[indexPath.row].section
        return assign6Cell
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "itemSegue"{
            let assign6Output = segue.destination as! GroceryItemsViewController
            assign6Output.items = grocerys[(grocerySectionsTableView.indexPathForSelectedRow?.row)!]
        }
    }
}
