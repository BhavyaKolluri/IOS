//
//  GroceryItemsViewController.swift
//  Kolluri_GroceryApp
//
//  Created by student on 4/12/22.
//


import UIKit

class GroceryItemsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var assign6Grocery = GroceryItem()
    var assign6GrocerysArr = grocerys
    @IBOutlet weak var groceryItemsTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = items?.section
        groceryItemsTableView.delegate = self
        groceryItemsTableView.dataSource = self
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let assign6Cell = segue.identifier
        if assign6Cell == "itemInfoSegue"{
        let assign6Output = segue.destination as! ItemInfoViewController
        assign6Output.details = items!.items_Array[(groceryItemsTableView.indexPathForSelectedRow?.row)!]
        }
}
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return assign6GrocerysArr.count
    }
    var items : Grocery?
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = groceryItemsTableView.dequeueReusableCell(withIdentifier: "itemCell", for: indexPath)
        cell.textLabel?.text = items!.items_Array[indexPath.row].itemName
        return cell
    }
}
