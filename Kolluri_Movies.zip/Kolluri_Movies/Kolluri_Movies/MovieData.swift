//
//  MovieData.swift
//  Kolluri_Movies
//
//  Created by student on 4/28/22.
//

import Foundation
import UIKit

struct Movies {
    var title:String
    var image:UIImage
    var releasedYear:String
    var movieRating:String
    var boxOffice:String
    var moviePlot:String
    var cast:[String] = []
}

struct Genre {
    var category:String
    var movies:[Movies] = []
}

let Genre1 = Genre(category: "Drama",
                   movies: [
                    Movies(title: "Titanic", image: UIImage(named: "drama1")!, releasedYear: "1997", movieRating: "9.6", boxOffice: "$2.202 billion", moviePlot: "Encorporating both historical and fictionalized aspects, it is based on accounts of the sinking.", cast: ["Kate Winslet","Leonardo Dicaprio"]),
                    Movies(title: "Twillight Saga: New Moon", image: UIImage(named: "drama2")!, releasedYear: "2009", movieRating: "5.5", boxOffice: "$407.1M", moviePlot: "When Bella Swan moves to a small town in the Pacific Northwest, she falls in love with Edward", cast: ["Robbert Pattinson","Kristen Stewart","Taylor"]),
                    Movies(title: "Twillight Saga: Eclipse", image: UIImage(named: "drama3")!, releasedYear: "2010", movieRating: "5", boxOffice: "$68M", moviePlot: "In Seattle, not far from Forks, Victoria attacks Riley Biers, so she can begin to create an army.", cast: ["Robbert Pattinson","Kristen Stewart","Taylor"]),
                    Movies(title: "Twillight Saga: Breaking Dawn", image: UIImage(named: "drama4")!, releasedYear: "2011", movieRating: "5.3", boxOffice: "$829.7M", moviePlot: "Bella (Kristen Stewart) awakes as a vampire from her life-threatening labor, her daughter", cast: ["Robbert Pattinson","Kristen Stewart","Taylor"]),
                    Movies(title: "Life of Pi", image: UIImage(named: "drama5")!, releasedYear: "2022", movieRating: "7.9", boxOffice: "609M", moviePlot: "Life of Pi is a Canadian philosophical novel by Yann Martel published in 2001", cast: ["Suraj Sharma","Irrfan Khan","Tabu"])])

let Genre2 = Genre(category: "Fantasy",
                   movies: [
                    Movies(title: "Harry Potter and the Sorcerer's Stone", image: UIImage(named: "fantasy1")!, releasedYear: "2001", movieRating: "7.6", boxOffice: "974.8M", moviePlot: "The trio discover that Fluffy is guarding the philosopher's stone, a magical object.", cast: ["Daniel Radcliff","Rupert Grint","Emma Watson"]),
                    Movies(title: "Harry Potter and the Chamber of secrets", image: UIImage(named: "fantasy2")!, releasedYear: "2002", movieRating: "7.4", boxOffice: "879.6M", moviePlot: "THarry's second year at Hogwarts School of Witchcraft and Wizardry is Heir of Salazar.", cast: ["Daniel Radcliff","Rupert Grint","Emma Watson"]),
                    Movies(title: "Harry Potter and the Prisoner of Azkaban", image: UIImage(named: "fantasy3")!, releasedYear: "2004", movieRating: "7.9", boxOffice: "797.4.8M", moviePlot: "Prisoner of Azkabhan escapes from jail.", cast: ["Daniel Radcliff","Rupert Grint","Emma Watson"]),
                    Movies(title: "Harry Potter and the Goblet of Fire", image: UIImage(named: "fantasy4")!, releasedYear: "2005", movieRating: "7.7", boxOffice: "896.7M", moviePlot: "Harry Potter, a wizard in his fourth year at Hogwarts School of Witchcraft and Wizardry.", cast: ["Daniel Radcliff","Rupert Grint","Emma Watson"]),
                    Movies(title: "Harry Potter and the Deathly Hallows", image: UIImage(named: "fantasy5")!, releasedYear: "2010", movieRating: "7.7", boxOffice: "250M", moviePlot: "Story follows Harry Potter, who has been asked by Dumbledore to destroy Voldemort's secret.", cast: ["Daniel Radcliff","Rupert Grint","Emma Watson"])])

let Genre3 = Genre(category: "Action",
                   movies: [
                    Movies(title: "Avatar", image: UIImage(named: "action1")!, releasedYear: "2009", movieRating: "7.9", boxOffice: "$760.5M", moviePlot: "While escorting avatar is attacked by a thanator and flees into the forest.", cast: ["Sam Worthington", "Zoe Saldana"]),
                    Movies(title: "Spider man no way home", image: UIImage(named: "action2")!, releasedYear: "2021", movieRating: "8.4", boxOffice: "$1.89 billion,", moviePlot: "In the film, Parker asks Dr. Stephen Strange to use magic to make his identity as Spider-Man.", cast: ["Tom Holland","Zendaya","Benedict Cumberbatch"]),
                    Movies(title: "The Batman", image: UIImage(named: "action3")!, releasedYear: "2022", movieRating: "8.7", boxOffice: "759.5M", moviePlot: "Reclusive billionaire Bruce Wayne, who has operated for two years as the vigilante Batman.", cast: ["Robert Pattinson","Zoë Kravitz","Paul Dano"]),
                    Movies(title: "Saho", image: UIImage(named: "action4")!, releasedYear: "2019", movieRating: "9.8", boxOffice: "900M", moviePlot: "Ibrahim, Roy's most trusted subordinate, reveals to Kalki, that Roy's family has been killed.", cast: ["Prabhas","Shraddha Kapoor","Jackie Shroff"]),
                    Movies(title: "Radhe Shyam", image: UIImage(named: "action5")!, releasedYear: "2022", movieRating: "9.6", boxOffice: "800M", moviePlot: "Vikramaditya, who does not believe in romantic relationships, instantly falls for doctor Prerana.", cast: ["Prabhas","Pooja Hegde"])])

let moviesStack = [Genre1,Genre2,Genre3]
