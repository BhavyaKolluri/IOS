//
//  MovieCollectionViewCell.swift
//  Kolluri_Movies
//
//  Created by student on 4/28/22.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    func assignMovie(with movie:Movies){
        imageViewOutlet.image = movie.image
    }
}
